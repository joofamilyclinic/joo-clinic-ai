AI Receptionist for Joo Family Clinic
